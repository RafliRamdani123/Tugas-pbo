package ProgramPenjumlahan;

public class ProgramPenjumlahan {

    public static void main(String[] args) {
        // Deklarasi dan inisialisasi variabel
        int angkaPertama = 5;
        int angkaKedua = 7;
        int hasil;

        // Melakukan perhitungan penjumlahan
        hasil = angkaPertama + angkaKedua;

        // Menampilkan hasil penjumlahan
        System.out.println("Hasil penjumlahan: " + hasil);
    }
}