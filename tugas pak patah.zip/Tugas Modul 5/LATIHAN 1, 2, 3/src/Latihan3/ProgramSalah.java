package Latihan3;

public class ProgramSalah {
    public static void main(String[] args) {
        int x = 5;
        int y = 10;
        
        if (x < y) {
            System.out.println("x lebih kecil dari y");
        } else {
            System.out.println("x lebih besar dari y");
        }
        
        int z = x + y;
        
        for (int i = 0; i < z; i++) {
            System.out.print(i + " ");
        }
    }
}
