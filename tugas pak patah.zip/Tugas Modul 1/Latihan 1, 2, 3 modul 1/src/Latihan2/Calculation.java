package Latihan2;

public class Calculation {

    public static void main(String[] args) {
        int x = 5;
        int y = 10;
        int sum = x + y;
        System.out.println("hasil Penjumlahan: " + sum);
    }
}