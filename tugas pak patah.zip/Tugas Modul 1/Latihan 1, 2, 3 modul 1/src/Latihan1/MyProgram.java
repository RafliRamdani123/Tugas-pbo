package Latihan1;

public class MyProgram {
    public static void main(String[] args) {
        System.out.println("hello, word");
    }
}
