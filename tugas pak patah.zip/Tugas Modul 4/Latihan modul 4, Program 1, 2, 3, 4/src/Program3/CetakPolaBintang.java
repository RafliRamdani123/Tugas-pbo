package Program3;

public class CetakPolaBintang {
    public static void main(String[] args) {
        int tinggi = 5; // Tinggi segitiga
        
        // Looping untuk baris
        for (int i = tinggi; i >= 1; i--) {
            // Looping untuk spasi di setiap baris
            for (int j = 0; j < tinggi - i; j++) {
                System.out.print(" ");
            }
            // Looping untuk bintang di setiap baris
            for (int k = 0; k < 2 * i - 1; k++) {
                System.out.print("*");
            }
            // Pindah ke baris berikutnya
            System.out.println();
        }
    }
}
