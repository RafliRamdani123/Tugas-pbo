package Kalkulator;

import java.util.Scanner;

public class Kalkulator {
    public static void main(String[] args) {
        java.util.Scanner input = new Scanner(System.in);
        char pilihan;

        do {
            System.out.println("Selamat datang di kalkulator Sederhana");
            System.out.println("Pilih Operasi yang anda inginkan");
            System.out.println("1. Penjumlahan (+)");
            System.out.println("2. Pengurangan (-)");
            System.out.println("3. Perkalian (*)");
            System.out.println("4. Pembagian (/)");
            System.out.println("Masukan pilihan (1/2/3/4)");
            int operasi = input.nextInt();

            System.out.println("Masukan angka pertama: ");
            double angka1 = input.nextDouble();

            System.out.println("Masukan Angka Kedua: ");
            double angka2 = input.nextDouble();

            switch (operasi) {
                case 1:
                    System.out.println("Hasil: " + tambah(angka1, angka2));
                    break;
                case 2:
                    System.out.println("Hasil: " + kurang(angka1, angka2));
                    break;
                case 3:
                    System.out.println("Hasil: " + kali(angka1, angka2));
                    break;
                case 4:
                    System.out.println("Hasil: " + bagi(angka1, angka2));
                    break;
                default:
                    System.out.println("Operasi tidak valid");
                    break;
            }
            System.out.println("Apakah anda ingin melakukan operasi lain? (y/n): ");
            pilihan = input.next().charAt(0);
        }while (pilihan == 'y');

        System.out.println("Terimakasih telah menggunakan kalkulator ini.");
        input.close();
    }
    public static double tambah(double angka1, double angka2) {
        return angka1 + angka2;
    }

    public static double kurang(double angka1, double angka2) {
        return angka1 - angka2;
    }

    public static double kali(double angka1, double angka2) {
        return angka1 * angka2;
    }

    public static double bagi(double angka1, double angka2) {
        if (angka2 == 0) {
            System.out.println("Error: Tidak dapat membagi oleh nol");
            return 0;
        } else {
            return angka1 / angka2;
        }
    }
}

