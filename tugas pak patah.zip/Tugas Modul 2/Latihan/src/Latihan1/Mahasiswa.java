package Latihan1;

public class Mahasiswa {
    private String nim;
    private String nama;
    private String jurusan;
    
    public Mahasiswa(String nim, String nama, String jurusan) {
        this.nim = nim;
        this.nama = nama;
        this.jurusan = jurusan;
    }
    
    public String getNim() {
        return nim;
    }
    
    public void setNim(String nim) {
        this.nim = nim;
    }
    
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String getJurusan() {
        return jurusan;
    }
    
    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }
    
    public void info() {
        System.out.println("NIM: " + nim);
        System.out.println("Nama: " + nama);
        System.out.println("Jurusan: " + jurusan);
    }

    public static void main(String[] args) {
        Mahasiswa mhs1 = new Mahasiswa("123456789", "John Doe", "Teknik Informatika");
        Mahasiswa mhs2 = new Mahasiswa("987654321", "Jane Smith", "Sistem Informasi");
        
        System.out.println("Data Mahasiswa 1:");
        mhs1.info();
        
        System.out.println();
        
        System.out.println("Data Mahasiswa 2:");
        mhs2.info();
        
        System.out.println();
        
        // Latihan 1: Ubah Nama Mahasiswa 1 menjadi "Michael Johnson"
        mhs1.setNama("Michael Johnson");
        System.out.println("Data Mahasiswa 1 (Setelah Diubah Nama):");
        mhs1.info();
        
        System.out.println();
        
        // Latihan 2: Tampilkan NIM dan Jurusan Mahasiswa 2
        System.out.println("NIM Mahasiswa 2: " + mhs2.getNim());
        System.out.println("Jurusan Mahasiswa 2: " + mhs2.getJurusan());
    }
}

