package Program2;

public class JumlahDeret {
    public static void main(String[] args) {
        int n = 5; // Batas deret
        int jumlah = 0; // Variabel untuk menyimpan jumlah deret
        
        // Looping untuk menjumlahkan deret bilangan
        for (int i = 1; i <= n; i++) {
            jumlah += i; // Menambahkan nilai i ke jumlah
        }
        
        // Menampilkan jumlah deret
        System.out.println("Jumlah deret bilangan dari 1 hingga " + n + " adalah: " + jumlah);
    
    }
}
