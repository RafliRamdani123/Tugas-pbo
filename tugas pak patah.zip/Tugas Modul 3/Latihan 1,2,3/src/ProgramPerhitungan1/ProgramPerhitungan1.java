package ProgramPerhitungan1;

public class ProgramPerhitungan1 {
    public static void main(String[] args) {
         // Mendeklarasikan variabel yang diperlukan
         int angkaPertama = 10;
         double angkaKedua = 3.5;
         double hasil; // Menggunakan tipe data double untuk hasil
 
         // Melakukan perhitungan dan menetapkan hasil ke variabel "hasil"
         hasil = angkaPertama / angkaKedua;
 
         // Menampilkan hasil perhitungan
         System.out.println("Hasil perhitungan: " + hasil);
    }
}
