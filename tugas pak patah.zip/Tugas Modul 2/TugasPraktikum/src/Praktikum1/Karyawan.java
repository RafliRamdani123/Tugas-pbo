package Praktikum1;

public class Karyawan {
    private String nip;
    private String nama;
    private String jabatan;
    public Karyawan(String nip, String nama, String jabatan) {
        this.nip = nip;
        this.nama = nama;
        this.jabatan = jabatan;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public static void main(String[] args) {
        Karyawan karyawan1 = new Karyawan("362379013", "Rafli Ramdani Sulaeman", "Boss muda");
        System.out.println("Informasi Karyawan:");
        System.out.println("NIP: " + karyawan1.getNip());
        System.out.println("Nama: " + karyawan1.getNama());
        System.out.println("Jabatan: " + karyawan1.getJabatan());
    }
}
