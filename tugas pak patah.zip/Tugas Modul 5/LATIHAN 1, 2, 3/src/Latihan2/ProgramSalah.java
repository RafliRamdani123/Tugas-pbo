package Latihan2;

public class ProgramSalah {
    public static void main(String[] args) {
        int x = 5; // Added a semicolon to terminate the statement
        if (x > 0) {
            System.out.println("Angka positif");
        } else {
            System.out.println("Angka negatif");
        }
    }
}
