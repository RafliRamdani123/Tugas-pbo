package Latihan1;

public class ProgramSalah {
    public static void main(String[] args) {

        int x = 5;
        int y = 10;

        int z = x + y;

        System.out.println("Hasil penjumlahan: " + z);

        if (z > 10)
            System.out.println("Nilai z lebih besar dari 10");
        else
            System.out.println("Nilai z kurang dari atau sama dengan 10");

        for (int i = 0; i < 5; i++) { // Corrected the syntax of the for loop
            System.out.println("Iterasi ke-" + i);
        }
    }

}