package Program;

public class main {

    public static void main(String[] args) {
        // Deklarasi dan inisialisasi variabel
        int umur = 25;
        double beratBadan = 60.5;
        char jenisKelamin = 'L';
        boolean isSudahMenikah = false;

        // Penggunaan operator aritmatika
        double bmi = beratBadan / ((umur / 10.0) * (umur / 10.0)); // Menghitung BMI

        // Penggunaan operator penugasan
        int tahunPensiun = 65;
        int sisaTahunKerja = tahunPensiun - umur;

        // Penggunaan operator pembanding
        if (umur >= 18) {
            System.out.println("Anda sudah dewasa");
        } else {
            System.out.println("Anda masih di bawah umur");
        }

        // Penggunaan operator logika
        if (jenisKelamin == 'L' && umur >= 21) {
            System.out.println("Anda adalah laki-laki dewasa");
        }

        // Penggunaan modifier akses dan final
        final String nama = "Rafli Ramdani Sulaeman"; // Variabel final

        // Output hasil
        System.out.println("Umur: " + umur);
        System.out.println("Berat Badan: " + beratBadan + " kg");
        System.out.println("Jenis Kelamin: " + jenisKelamin);
        System.out.println("Sudah Menikah: " + isSudahMenikah);
        System.out.println("BMI: " + bmi);
        System.out.println("Sisa Tahun Kerja: " + sisaTahunKerja);
        System.out.println("Nama: " + nama);
    }
}