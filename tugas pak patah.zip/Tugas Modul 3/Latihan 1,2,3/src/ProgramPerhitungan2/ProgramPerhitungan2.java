package ProgramPerhitungan2;

public class ProgramPerhitungan2 {
    public static void main(String[] args) {
        // Deklarasi variabel yang diperlukan
        double angkaPertama = 5.5;
        int angkaKedua = 2;
        double hasil; // Menggunakan tipe data double untuk hasil

        // Melakukan perhitungan dan menetapkan hasil ke variabel "hasil"
        hasil = angkaPertama * angkaKedua;

        // Menampilkan hasil perhitungan
        System.out.println("Hasil perhitungan: " + hasil);
    
    }
}
