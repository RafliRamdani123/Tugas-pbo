package Program4;

public class PerkalianTabel {
    public static void main(String[] args) {
         // Looping untuk mengatur baris
         for (int i = 1; i <= 10; i++) {
            // Looping untuk mengatur kolom
            for (int j = 1; j <= 10; j++) {
                // Menghitung hasil perkalian
                int hasil = i * j;
                // Mencetak hasil perkalian
                System.out.print(hasil + "\t");
            }
            // Pindah ke baris baru setelah selesai mencetak satu baris
            System.out.println();
        }
    }
}
