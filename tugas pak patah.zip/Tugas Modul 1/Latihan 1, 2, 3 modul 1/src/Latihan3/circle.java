package Latihan3;

public class circle {
    public static void main(String[] args) {
        double radius = 5.0;
        double circumference = 2 * Math.PI * radius;
        System.out.println("keliling lingkaran: " + circumference);
    }
}
