package JavaMain;

public class JavaBuku {
    public static class Buku {
        private String judul;
        private String pengarang;
        private int tahunTerbit;
        
        public Buku(String judul, String pengarang, int tahunTerbit) {
            this.judul = judul;
            this.pengarang = pengarang;
            this.tahunTerbit = tahunTerbit;
        }
        
        public String getJudul() {
            return judul;
        }
        
        public void setJudul(String judul) {
            this.judul = judul;
        }
        
        public String getPengarang() {
            return pengarang;
        }
        
        public void setPengarang(String pengarang) {
            this.pengarang = pengarang;
        }
        
        public int getTahunTerbit() {
            return tahunTerbit;
        }
        
        public void setTahunTerbit(int tahunTerbit) {
            this.tahunTerbit = tahunTerbit;
        }
        
        public void info() {
            System.out.println("Judul: " + judul);
            System.out.println("Pengarang: " + pengarang);
            System.out.println("Tahun Terbit: " + tahunTerbit);
        }
    }
    
    public static void main(String[] args) {
        Buku buku1 = new Buku("Harry Potter", "J.K. Rowling", 1997);
        Buku buku2 = new Buku("The Great Gatsby", "F. Scott Fitzgerald", 1925);
        
        System.out.println("Data Buku 1:");
        buku1.info();
        
        System.out.println();
        
        System.out.println("Data Buku 2:");
        buku2.info();
        
        System.out.println();
        
        // Latihan 1: Ubah Tahun Terbit Buku 1 menjadi 2001
        buku1.setTahunTerbit(2001);
        System.out.println("Data Buku 1 (Setelah Diubah Tahun Terbit):");
        buku1.info();
        
        System.out.println();
        
        // Latihan 2: Tampilkan Pengarang Buku 2
        System.out.println("Pengarang Buku 2: " + buku2.getPengarang());
    }
}