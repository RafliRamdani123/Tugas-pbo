package Praktikum2;

public class Barang {
    private String kode;
    private String namabarang;
    private double harga;

    public Barang(String kode, String namabarang, double harga) {
        this.kode = kode;
        this.namabarang = namabarang;
        this.harga = harga;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getNamabarang() {
        return namabarang;
    }

    public void setNamabarang(String namabarang) {
        this.namabarang = namabarang;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public static void main(String[] args) {
        Barang barang1 = new Barang("B001", "Iphone 20 pro Max", 25000000);
        System.out.println("Informasi Barang:");
        System.out.println("Kode: " + barang1.getKode());
        System.out.println("Nama Barang: " + barang1.getNamabarang());
        System.out.println("Harga: " + barang1.getHarga());
    }
}
